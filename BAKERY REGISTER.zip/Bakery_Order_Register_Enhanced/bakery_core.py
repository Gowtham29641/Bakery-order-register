import json, csv, io
from pathlib import Path
from datetime import date, datetime, timedelta
import random

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATA_FILE = DATA_DIR / "orders.json"
STATUSES = ["Pending", "In Progress", "Completed", "Cancelled"]

def load_orders(path=DATA_FILE):
    try:
        DATA_DIR.mkdir(exist_ok=True)
        if not path.exists():
            path.write_text("[]", encoding="utf-8")
            return []
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, list): return []
        valid = []
        for item in data:
            if isinstance(item, dict) and all(k in item for k in ["order_id","customer","item","pickup_date","total_amount","amount_paid"]):
                valid.append(item)
        return valid
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("[]", encoding="utf-8")
        return []

def save_orders(orders, path=DATA_FILE):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(orders, indent=2, ensure_ascii=False), encoding="utf-8")
    temp.replace(path)

def validate_order(p):
    for key, label in [("customer","Customer name"),("item","Bakery item")]:
        if not str(p.get(key,"")).strip(): return f"{label} is required."
    try:
        q = int(p.get("quantity", 0))
        price = float(p.get("unit_price", -1))
        paid = float(p.get("amount_paid", -1))
        pickup = date.fromisoformat(str(p.get("pickup_date","")))
    except (ValueError, TypeError):
        return "Enter valid quantity, price, payment amount and pickup date."
    if q < 1 or q > 500: return "Quantity must be between 1 and 500."
    if price < 0 or paid < 0: return "Price and payment cannot be negative."
    if paid > q * price: return "Amount received cannot exceed the total order value."
    if p.get("order_status","Pending") not in STATUSES: return "Choose a valid order status."
    phone = str(p.get("phone","")).strip()
    if phone and not phone.replace("+","").replace("-","").replace(" ","").isdigit():
        return "Phone number may contain only digits, spaces, + or -."
    return None

def add_order(orders, p):
    n = max([int(o.get("order_id","BR-0000").split("-")[-1]) for o in orders] + [0]) + 1
    total = round(int(p["quantity"]) * float(p["unit_price"]), 2)
    paid = round(float(p.get("amount_paid",0)), 2)
    status = "Paid" if paid >= total else ("Partially Paid" if paid > 0 else "Unpaid")
    record = {"order_id":f"BR-{n:04d}","customer":str(p["customer"]).strip(),"phone":str(p.get("phone","")).strip(),
              "item":str(p["item"]).strip(),"flavour":str(p.get("flavour","")).strip(),"quantity":int(p["quantity"]),
              "unit_price":round(float(p["unit_price"]),2),"total_amount":total,"amount_paid":paid,"balance":round(total-paid,2),
              "pickup_date":str(p["pickup_date"]),"payment_status":status,"order_status":p.get("order_status","Pending"),
              "notes":str(p.get("notes","")).strip(),"created_at":datetime.now().isoformat(timespec="seconds")}
    return orders + [record]

def update_order(orders, order_id, changes):
    result=[]
    for o in orders:
        x=o.copy()
        if x["order_id"] == order_id:
            x.update(changes)
            x["balance"]=round(float(x["total_amount"])-float(x["amount_paid"]),2)
            x["payment_status"]="Paid" if x["balance"] == 0 else ("Partially Paid" if x["amount_paid"] > 0 else "Unpaid")
        result.append(x)
    return result

def delete_order(orders, order_id):
    return [o for o in orders if o["order_id"] != order_id]

def search_orders(orders, query="", payment="All", status="All"):
    q=query.lower().strip()
    out=[]
    for o in orders:
        hay=" ".join(str(v) for v in o.values()).lower()
        if q and q not in hay: continue
        if payment != "All" and o.get("payment_status") != payment: continue
        if status != "All" and o.get("order_status") != status: continue
        out.append(o)
    return out

def summarize(orders):
    total=len(orders); revenue=sum(float(o.get("total_amount",0)) for o in orders)
    paid=sum(float(o.get("amount_paid",0)) for o in orders)
    return {"total":total,"revenue":round(revenue,2),"paid":round(paid,2),"pending":round(revenue-paid,2),
            "average":round(revenue/total,2) if total else 0,
            "paid_orders":sum(o.get("payment_status")=="Paid" for o in orders),
            "partial_orders":sum(o.get("payment_status")=="Partially Paid" for o in orders),
            "unpaid_orders":sum(o.get("payment_status")=="Unpaid" for o in orders)}

def export_csv_bytes(orders):
    fields=["order_id","customer","phone","item","flavour","quantity","unit_price","total_amount","amount_paid","balance","pickup_date","payment_status","order_status","notes","created_at"]
    s=io.StringIO(); w=csv.DictWriter(s,fieldnames=fields); w.writeheader()
    for o in orders: w.writerow({k:o.get(k,"") for k in fields})
    return s.getvalue().encode("utf-8-sig")

def export_markdown(orders):
    s=summarize(orders)
    lines=["# Bakery Order Register Summary","",f"- Total orders: {s['total']}",f"- Total sales value: ₹{s['revenue']:.2f}",f"- Amount received: ₹{s['paid']:.2f}",f"- Pending balance: ₹{s['pending']:.2f}",f"- Average order value: ₹{s['average']:.2f}","","## Orders","",
           "| Order ID | Customer | Item | Pickup | Total | Paid | Balance | Payment | Status |","|---|---|---|---|---:|---:|---:|---|---|"]
    for o in orders:
        lines.append(f"| {o['order_id']} | {o['customer']} | {o['item']} | {o['pickup_date']} | {o['total_amount']:.2f} | {o['amount_paid']:.2f} | {o['balance']:.2f} | {o['payment_status']} | {o['order_status']} |")
    return "\n".join(lines)

def seed_demo_data():
    random.seed(87)
    names=["Ananya Rao","Rahul Kumar","Sravya Reddy","Kiran Teja","Meghana Das","Arjun Patel","Nisha Varma","Sai Charan","Pooja Singh","Vikram Rao"]
    items=["Chocolate Truffle Cake","Vanilla Birthday Cake","Black Forest Cake","Red Velvet Cake","Butterscotch Cake","Cupcake Box","Pineapple Cake","Brownie Box"]
    flavours=["Eggless","1 kg, custom name","Half kg","Floral design","Photo cake","No nuts","Classic"]
    result=[]
    for i in range(40):
        qty=random.choice([1,1,1,2,3])
        price=random.choice([450,550,650,750,850,1000,1250])
        total=qty*price
        paid=random.choice([0,0,total/2,total])
        pickup=(date.today()+timedelta(days=random.randint(-3,14))).isoformat()
        payload={"customer":random.choice(names),"phone":f"9{random.randint(100000000,999999999)}","item":random.choice(items),
                 "flavour":random.choice(flavours),"quantity":qty,"unit_price":price,"pickup_date":pickup,
                 "amount_paid":paid,"order_status":random.choice(STATUSES),"notes":"Demo sample record"}
        result=add_order(result,payload)
    return result
