# Crumb & Co. — Bakery Order Studio

A full-stack bakery order management website. The frontend and backend are included
in this **single project folder** and communicate through the Flask API.

## One-click run (Windows)

1. Extract this ZIP file.
2. Open the extracted `Bakery_Order_Register_Enhanced` folder.
3. Double-click **`RUN_PROJECT.bat`**.
4. The first run creates a Python virtual environment and installs Flask.
5. Your browser opens at **http://127.0.0.1:5000**. Keep the black terminal window open.

Requirements: Windows and Python 3.10+ installed. Internet is needed for the first
dependency installation. If Python is missing, install it from
https://www.python.org/downloads/ and enable "Add Python to PATH".

## What's included

- `RUN_PROJECT.bat` — one-click Windows launcher
- `web_app.py` — Flask website server and REST API
- `bakery_core.py` — order calculations, validation, search and reporting logic
- `website/index.html` — website structure
- `website/styles.css` — responsive visual design
- `website/app.js` — interactive frontend and API integration
- `data/orders.json` — persistent local order data
- `tests/` — automated tests
- `sample_import.csv` — sample CSV import format

## Features

Dashboard, order creation, order search and filters, order updates and deletion,
payment tracking, pickup schedule, CSV import/export, summary reports and JSON
file-based persistence.

## Run tests

Open Command Prompt in this folder and run:

```bat
.venv\Scripts\python.exe -m unittest discover -s tests -v
```

## Data and deployment

The app is configured for local demonstration on `127.0.0.1:5000`. Orders are
stored in `data/orders.json`; back up this file before replacing project files.
The built-in Flask development server is for local coursework/demo use, not public
production hosting. Public deployment should add authentication, production hosting
and a production database.

Marks depend on your institution's rubric and project demonstration; no result can
be guaranteed.
