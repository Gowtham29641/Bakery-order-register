"""Flask REST API for the Crumb & Co. Bakery Order Register."""
from datetime import date
from pathlib import Path
import csv
import io

from flask import Flask, jsonify, request, send_from_directory, Response
from bakery_core import (
    load_orders, save_orders, add_order, update_order, delete_order,
    summarize, search_orders, validate_order, export_csv_bytes, DATA_FILE
)

BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = BASE_DIR / "website"
app = Flask(__name__, static_folder=str(WEB_DIR), static_url_path="/static")
app.config["JSON_SORT_KEYS"] = False

def current_orders():
    return load_orders(DATA_FILE)

def persist(rows):
    save_orders(rows, DATA_FILE)

@app.get("/")
def home():
    return send_from_directory(WEB_DIR, "index.html")

@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "service": "Bakery Order Register API"})

@app.get("/api/orders")
def get_orders():
    rows = current_orders()
    q = request.args.get("q", "")
    payment = request.args.get("payment", "All")
    status = request.args.get("status", "All")
    found = search_orders(rows, q, payment, status)
    return jsonify({"orders": found, "count": len(found)})

@app.post("/api/orders")
def create_order():
    payload = request.get_json(silent=True) or {}
    error = validate_order(payload)
    if error:
        return jsonify({"error": error}), 400
    rows = add_order(current_orders(), payload)
    persist(rows)
    return jsonify({"message": "Order created", "order": rows[-1]}), 201

@app.patch("/api/orders/<order_id>")
def edit_order(order_id):
    rows = current_orders()
    existing = next((o for o in rows if o.get("order_id") == order_id), None)
    if not existing:
        return jsonify({"error": "Order not found"}), 404
    changes = request.get_json(silent=True) or {}
    allowed = {"amount_paid", "order_status", "pickup_date", "notes"}
    if not changes or set(changes) - allowed:
        return jsonify({"error": "Only amount_paid, order_status, pickup_date and notes can be updated."}), 400
    candidate = existing.copy()
    candidate.update(changes)
    try:
        paid = float(candidate["amount_paid"])
        pickup = date.fromisoformat(str(candidate["pickup_date"]))
    except (ValueError, TypeError, KeyError):
        return jsonify({"error": "Enter a valid payment amount and pickup date."}), 400
    if paid < 0 or paid > float(existing["total_amount"]):
        return jsonify({"error": "Payment must be between ₹0 and the order total."}), 400
    if candidate.get("order_status") not in ["Pending", "In Progress", "Completed", "Cancelled"]:
        return jsonify({"error": "Invalid order status."}), 400
    if not str(candidate.get("notes", "")) and "notes" in changes:
        candidate["notes"] = ""
    updates = {k: candidate[k] for k in allowed if k in candidate}
    updated = update_order(rows, order_id, updates)
    persist(updated)
    return jsonify({"message": "Order updated", "order": next(o for o in updated if o["order_id"] == order_id)})

@app.delete("/api/orders/<order_id>")
def remove_order(order_id):
    rows = current_orders()
    if not any(o.get("order_id") == order_id for o in rows):
        return jsonify({"error": "Order not found"}), 404
    updated = delete_order(rows, order_id)
    persist(updated)
    return jsonify({"message": "Order deleted"})

@app.get("/api/summary")
def summary():
    rows = current_orders()
    return jsonify(summarize(rows))

@app.get("/api/export.csv")
def export_csv():
    return Response(export_csv_bytes(current_orders()), mimetype="text/csv",
                    headers={"Content-Disposition": 'attachment; filename="bakery_orders.csv"'})

@app.post("/api/import.csv")
def import_csv():
    upload = request.files.get("file")
    if not upload:
        return jsonify({"error": "Choose a CSV file to import."}), 400
    try:
        text = upload.stream.read().decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(text))
        required = {"customer", "item", "pickup_date", "quantity", "unit_price"}
        if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
            return jsonify({"error": "CSV must include: customer, item, pickup_date, quantity, unit_price."}), 400
        rows, errors = current_orders(), []
        imported = 0
        for line_no, row in enumerate(reader, start=2):
            try:
                payload = {
                    "customer": row.get("customer", ""),
                    "phone": row.get("phone", ""),
                    "item": row.get("item", ""),
                    "flavour": row.get("flavour", ""),
                    "quantity": int(row.get("quantity") or 1),
                    "unit_price": float(row.get("unit_price") or 0),
                    "pickup_date": row.get("pickup_date", ""),
                    "amount_paid": float(row.get("amount_paid") or 0),
                    "order_status": row.get("order_status") or "Pending",
                    "notes": row.get("notes", "")
                }
                error = validate_order(payload)
                if error:
                    raise ValueError(error)
                rows = add_order(rows, payload)
                imported += 1
            except (ValueError, TypeError) as exc:
                errors.append(f"Row {line_no}: {exc}")
        persist(rows)
        return jsonify({"message": f"Imported {imported} order(s).", "imported": imported, "errors": errors[:30]})
    except UnicodeDecodeError:
        return jsonify({"error": "Please upload a UTF-8 CSV file."}), 400

@app.get("/api/template.csv")
def csv_template():
    content = "customer,phone,item,flavour,quantity,unit_price,pickup_date,amount_paid,order_status,notes\n"
    return Response(content, mimetype="text/csv",
                    headers={"Content-Disposition": 'attachment; filename="bakery_import_template.csv"'})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
