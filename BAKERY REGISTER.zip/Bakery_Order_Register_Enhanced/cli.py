from bakery_core import load_orders, save_orders, add_order, validate_order, summarize, search_orders, export_markdown
from datetime import date

def ask(text):
    return input(text).strip()

def main():
    orders=load_orders()
    while True:
        print("\n=== BAKERY ORDER REGISTER ===")
        print("1. Add order\n2. View orders\n3. Search orders\n4. Summary\n5. Export Markdown report\n0. Exit")
        choice=ask("Choose: ")
        if choice=="1":
            p={"customer":ask("Customer name: "),"phone":ask("Phone: "),"item":ask("Bakery item: "),
               "flavour":ask("Flavour/details: "),"quantity":ask("Quantity: "),"unit_price":ask("Unit price: "),
               "pickup_date":ask("Pickup date (YYYY-MM-DD): "),"amount_paid":ask("Amount paid: "),
               "order_status":"Pending","notes":ask("Notes: ")}
            try:
                p["quantity"]=int(p["quantity"]); p["unit_price"]=float(p["unit_price"]); p["amount_paid"]=float(p["amount_paid"])
                error=validate_order(p)
                if error: print("Invalid:",error); continue
                orders=add_order(orders,p); save_orders(orders); print("Order saved.")
            except ValueError: print("Please enter valid numeric values.")
        elif choice=="2":
            for o in orders: print(o["order_id"],"|",o["customer"],"|",o["item"],"|",o["pickup_date"],"|",o["payment_status"])
        elif choice=="3":
            q=ask("Search keyword: ")
            for o in search_orders(orders,q): print(o)
        elif choice=="4":
            print(summarize(orders))
        elif choice=="5":
            open("bakery_summary.md","w",encoding="utf-8").write(export_markdown(orders)); print("Saved bakery_summary.md")
        elif choice=="0": break
        else: print("Choose a valid menu option.")
if __name__=="__main__": main()
