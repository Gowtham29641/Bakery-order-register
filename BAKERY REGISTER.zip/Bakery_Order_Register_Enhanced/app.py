import streamlit as st
from bakery_core import load_orders, save_orders, add_order, update_order, delete_order, summarize, search_orders, export_csv_bytes, export_markdown, seed_demo_data, validate_order
from datetime import date, timedelta
import pandas as pd

st.set_page_config(page_title="Bakery Order Register", page_icon="🧁", layout="wide")
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap');
html, body, [class*="css"] {font-family:'DM Sans',sans-serif;}
.stApp {background:linear-gradient(135deg,#fffaf5 0%,#fff4ed 55%,#fdf0f3 100%);}
.block-container {padding-top:2rem;max-width:1400px;}
.hero {background:linear-gradient(120deg,#4b2638,#854b61);padding:28px 32px;border-radius:22px;color:white;margin-bottom:22px;box-shadow:0 12px 35px #5b2c3b20;}
.hero h1 {font-family:'Playfair Display',serif;font-size:2.4rem;margin:0;}
.hero p {color:#f5dce5;margin:.4rem 0 0;}
.metric {background:white;border:1px solid #f0dedb;border-radius:17px;padding:17px 19px;box-shadow:0 5px 18px #6c34400a;}
.metric-label {font-size:.82rem;color:#8b6a70;font-weight:600;}
.metric-value {font-size:1.8rem;color:#4b2638;font-weight:800;margin-top:4px;}
div[data-testid="stMetric"] {background:white;border:1px solid #f0dedb;padding:15px 18px;border-radius:16px;}
.stButton>button {border-radius:11px;font-weight:700;}
section[data-testid="stSidebar"] {background:#fff7f2;}
h2,h3 {color:#4b2638;}
</style>
""", unsafe_allow_html=True)

if "orders" not in st.session_state:
    st.session_state.orders = load_orders()

orders = st.session_state.orders
st.markdown("""<div class="hero"><h1>🧁 Bakery Order Register</h1>
<p>A simple, smart workspace to manage cake orders, pickup dates and payments.</p></div>""", unsafe_allow_html=True)

with st.sidebar:
    st.markdown("## 🧁 Bakery Desk")
    page = st.radio("NAVIGATION", ["Dashboard", "Add New Order", "Orders Register", "Search Orders", "Reports & Export", "Data Tools"])
    st.divider()
    st.caption("Local-first • JSON storage • CSV export")
    st.caption("Your records are saved in `data/orders.json`.")

summary = summarize(orders)
if page == "Dashboard":
    st.subheader("Business overview")
    c1,c2,c3,c4 = st.columns(4)
    c1.metric("Total orders", summary["total"])
    c2.metric("Revenue value", f"₹{summary['revenue']:,.2f}")
    c3.metric("Amount received", f"₹{summary['paid']:,.2f}")
    c4.metric("Pending balance", f"₹{summary['pending']:,.2f}")
    st.write("")
    a,b = st.columns([1.15,1])
    with a:
        st.markdown("### Payment status")
        if orders:
            counts = pd.Series([o["payment_status"] for o in orders]).value_counts()
            st.bar_chart(counts)
        else:
            st.info("Add an order to see payment analytics.")
    with b:
        st.markdown("### Order snapshot")
        st.metric("Paid orders", summary["paid_orders"])
        st.metric("Partially paid", summary["partial_orders"])
        st.metric("Unpaid orders", summary["unpaid_orders"])
        st.metric("Average order value", f"₹{summary['average']:,.2f}")
    st.markdown("### Upcoming & overdue pickups")
    today = date.today().isoformat()
    upcoming = [o for o in orders if o["pickup_date"] >= today and o["pickup_date"] <= (date.today()+timedelta(days=7)).isoformat()]
    overdue = [o for o in orders if o["pickup_date"] < today and o["order_status"] != "Completed"]
    if overdue:
        st.warning(f"⚠️ {len(overdue)} order(s) have a past pickup date and are not completed.")
    if upcoming:
        st.dataframe(pd.DataFrame(upcoming)[["order_id","customer","item","pickup_date","payment_status","order_status"]], use_container_width=True, hide_index=True)
    elif not overdue:
        st.success("No urgent pickup alerts. You're all caught up!")

elif page == "Add New Order":
    st.subheader("Create a bakery order")
    with st.form("new_order", clear_on_submit=True):
        x1,x2 = st.columns(2)
        customer = x1.text_input("Customer name *", placeholder="e.g. Ananya Rao")
        phone = x2.text_input("Phone number", placeholder="10-digit number")
        x3,x4 = st.columns(2)
        item = x3.text_input("Cake / bakery item *", placeholder="e.g. Chocolate truffle cake")
        flavour = x4.text_input("Flavour / details", placeholder="e.g. 1 kg, eggless, blue theme")
        x5,x6,x7 = st.columns(3)
        quantity = x5.number_input("Quantity", min_value=1, max_value=500, value=1, step=1)
        unit_price = x6.number_input("Unit price (₹)", min_value=0.0, value=750.0, step=50.0)
        pickup = x7.date_input("Pickup date", min_value=date.today(), value=date.today()+timedelta(days=1))
        x8,x9 = st.columns(2)
        paid = x8.number_input("Amount received (₹)", min_value=0.0, value=0.0, step=50.0)
        status = x9.selectbox("Order status", ["Pending", "In Progress", "Completed", "Cancelled"])
        notes = st.text_area("Special instructions", placeholder="Message on cake, design, delivery notes...")
        submitted = st.form_submit_button("＋ Save order", use_container_width=True)
    if submitted:
        payload = dict(customer=customer, phone=phone, item=item, flavour=flavour, quantity=int(quantity), unit_price=float(unit_price), pickup_date=pickup.isoformat(), amount_paid=float(paid), order_status=status, notes=notes)
        error = validate_order(payload)
        if error:
            st.error(error)
        else:
            st.session_state.orders = add_order(orders, payload)
            save_orders(st.session_state.orders)
            st.success("Order saved successfully. Your register has been updated.")
            st.rerun()

elif page == "Orders Register":
    st.subheader("All bakery orders")
    if not orders:
        st.info("No orders yet. Use Add New Order to create your first record.")
    else:
        df = pd.DataFrame(orders)
        show = df[["order_id","customer","phone","item","quantity","total_amount","amount_paid","balance","pickup_date","payment_status","order_status"]]
        st.dataframe(show, use_container_width=True, hide_index=True)
        st.markdown("### Update or remove an order")
        chosen = st.selectbox("Choose order", [o["order_id"] for o in orders])
        selected = next(o for o in orders if o["order_id"] == chosen)
        with st.form("edit_order"):
            y1,y2,y3 = st.columns(3)
            new_paid = y1.number_input("Amount received (₹)", min_value=0.0, value=float(selected["amount_paid"]), step=50.0)
            new_status = y2.selectbox("Order status", ["Pending","In Progress","Completed","Cancelled"], index=["Pending","In Progress","Completed","Cancelled"].index(selected["order_status"]))
            new_pickup = y3.date_input("Pickup date", value=date.fromisoformat(selected["pickup_date"]))
            save = st.form_submit_button("Update selected order")
        if save:
            updated = update_order(orders, chosen, {"amount_paid":float(new_paid),"order_status":new_status,"pickup_date":new_pickup.isoformat()})
            st.session_state.orders = updated
            save_orders(updated)
            st.success("Order updated.")
            st.rerun()
        if st.button("Delete selected order", type="secondary"):
            st.session_state.orders = delete_order(orders, chosen)
            save_orders(st.session_state.orders)
            st.warning(f"{chosen} deleted.")
            st.rerun()

elif page == "Search Orders":
    st.subheader("Find an order")
    q = st.text_input("Search by order ID, customer, phone, item, flavour or notes")
    f1,f2 = st.columns(2)
    pay_filter = f1.selectbox("Payment filter", ["All","Paid","Partially Paid","Unpaid"])
    status_filter = f2.selectbox("Order status filter", ["All","Pending","In Progress","Completed","Cancelled"])
    found = search_orders(orders, q, pay_filter, status_filter)
    st.caption(f"{len(found)} matching order(s)")
    if found:
        st.dataframe(pd.DataFrame(found), use_container_width=True, hide_index=True)
    else:
        st.info("No matching records found. Try another keyword or filter.")

elif page == "Reports & Export":
    st.subheader("Reports and downloads")
    s = summarize(orders)
    st.write(f"**Total orders:** {s['total']}  ·  **Total sales value:** ₹{s['revenue']:,.2f}  ·  **Outstanding:** ₹{s['pending']:,.2f}")
    st.download_button("⬇ Download orders as CSV", data=export_csv_bytes(orders), file_name="bakery_orders_report.csv", mime="text/csv", use_container_width=True)
    st.download_button("⬇ Download summary as Markdown", data=export_markdown(orders).encode("utf-8"), file_name="bakery_summary.md", mime="text/markdown", use_container_width=True)
    if orders:
        st.markdown("### Sales by order status")
        st.bar_chart(pd.DataFrame(orders).groupby("order_status")["total_amount"].sum())

elif page == "Data Tools":
    st.subheader("Data management")
    st.write("Import an existing CSV file. Required columns: customer, item, pickup_date, quantity, unit_price. Invalid rows are skipped and reported.")
    upload = st.file_uploader("Choose CSV file", type=["csv"])
    if upload and st.button("Import valid rows"):
        try:
            df = pd.read_csv(upload)
            imported, errors = [], []
            for idx, row in df.iterrows():
                try:
                    payload = {k: str(row.get(k,"")) for k in ["customer","phone","item","flavour","pickup_date","order_status","notes"]}
                    payload.update(quantity=int(row.get("quantity",1)), unit_price=float(row.get("unit_price",0)), amount_paid=float(row.get("amount_paid",0)))
                    if not payload["order_status"] or payload["order_status"] == "nan": payload["order_status"]="Pending"
                    err = validate_order(payload)
                    if err: raise ValueError(err)
                    imported.append(payload)
                except Exception as e:
                    errors.append(f"Row {idx+2}: {e}")
            new_orders = orders[:]
            for p in imported: new_orders = add_order(new_orders,p)
            st.session_state.orders = new_orders
            save_orders(new_orders)
            st.success(f"Imported {len(imported)} valid row(s).")
            if errors: st.warning("\n".join(errors[:15]))
        except Exception as e:
            st.error(f"Could not read CSV: {e}")
    st.divider()
    st.markdown("### Demo data")
    st.write("Load 40 realistic sample orders to explore the dashboard. This replaces the current records.")
    if st.button("Load 40 sample orders", type="secondary"):
        st.session_state.orders = seed_demo_data()
        save_orders(st.session_state.orders)
        st.success("40 sample orders loaded.")
        st.rerun()
    if st.button("Clear all records"):
        st.session_state.orders = []
        save_orders([])
        st.warning("All records cleared.")
        st.rerun()

st.divider()
st.caption("Bakery Order Register • Built with Python + Streamlit • Data is stored locally in JSON.")
