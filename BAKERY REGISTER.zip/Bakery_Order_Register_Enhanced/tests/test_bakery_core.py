import unittest
from datetime import date
from bakery_core import add_order, validate_order, summarize, search_orders, update_order, delete_order

class BakeryCoreTests(unittest.TestCase):
    def payload(self, **kwargs):
        p=dict(customer='Asha',phone='9876543210',item='Chocolate Cake',flavour='Eggless',quantity=2,unit_price=500,pickup_date=date.today().isoformat(),amount_paid=300,order_status='Pending',notes='Test')
        p.update(kwargs); return p
    def test_add_calculates_totals_and_balance(self):
        rows=add_order([],self.payload()); self.assertEqual(rows[0]['total_amount'],1000); self.assertEqual(rows[0]['balance'],700); self.assertEqual(rows[0]['payment_status'],'Partially Paid')
    def test_rejects_blank_customer(self): self.assertIn('required',validate_order(self.payload(customer='')))
    def test_rejects_overpayment(self): self.assertIn('cannot exceed',validate_order(self.payload(amount_paid=1001)))
    def test_rejects_bad_quantity(self): self.assertIn('Quantity',validate_order(self.payload(quantity=0)))
    def test_summary(self):
        rows=add_order([],self.payload()); s=summarize(rows); self.assertEqual(s['total'],1); self.assertEqual(s['revenue'],1000); self.assertEqual(s['pending'],700)
    def test_search_and_filters(self):
        rows=add_order([],self.payload()); self.assertEqual(len(search_orders(rows,'asha')),1); self.assertEqual(len(search_orders(rows,'','Partially Paid')),1)
    def test_update_payment(self):
        rows=add_order([],self.payload()); rows=update_order(rows,rows[0]['order_id'],{'amount_paid':1000}); self.assertEqual(rows[0]['payment_status'],'Paid')
    def test_delete(self):
        rows=add_order([],self.payload()); self.assertEqual(delete_order(rows,rows[0]['order_id']),[])

if __name__=='__main__': unittest.main()
