import json
import tempfile
import unittest
from pathlib import Path
try:
    import web_app
except ModuleNotFoundError:
    web_app = None

@unittest.skipIf(web_app is None, "Install Flask from requirements.txt to run API tests")
class BakeryApiTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_file = web_app.DATA_FILE
        web_app.DATA_FILE = Path(self.temp.name) / "orders.json"
        web_app.app.config["TESTING"] = True
        self.client = web_app.app.test_client()

    def tearDown(self):
        web_app.DATA_FILE = self.old_file
        self.temp.cleanup()

    def payload(self, **changes):
        p = {
            "customer": "Asha Rao", "phone": "9876543210",
            "item": "Chocolate Cake", "flavour": "Eggless",
            "quantity": 2, "unit_price": 500,
            "pickup_date": "2027-01-10", "amount_paid": 300,
            "order_status": "Pending", "notes": "Happy birthday"
        }
        p.update(changes)
        return p

    def test_health_and_home(self):
        self.assertEqual(self.client.get("/api/health").status_code, 200)
        self.assertEqual(self.client.get("/").status_code, 200)

    def test_create_list_summary_update_delete(self):
        response = self.client.post("/api/orders", json=self.payload())
        self.assertEqual(response.status_code, 201)
        order_id = response.get_json()["order"]["order_id"]
        self.assertEqual(self.client.get("/api/orders").get_json()["count"], 1)
        summary = self.client.get("/api/summary").get_json()
        self.assertEqual(summary["revenue"], 1000)
        self.assertEqual(summary["paid"], 300)
        changed = self.client.patch(f"/api/orders/{order_id}", json={"amount_paid": 1000, "order_status": "Completed"})
        self.assertEqual(changed.status_code, 200)
        self.assertEqual(changed.get_json()["order"]["payment_status"], "Paid")
        self.assertEqual(self.client.delete(f"/api/orders/{order_id}").status_code, 200)
        self.assertEqual(self.client.get("/api/orders").get_json()["count"], 0)

    def test_validation_and_missing_order(self):
        self.assertEqual(self.client.post("/api/orders", json=self.payload(quantity=0)).status_code, 400)
        self.assertEqual(self.client.patch("/api/orders/BR-9999", json={"amount_paid": 0}).status_code, 404)

    def test_csv_export(self):
        self.client.post("/api/orders", json=self.payload())
        response = self.client.get("/api/export.csv")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"customer", response.data)

if __name__ == "__main__":
    unittest.main()
